<?php
// encabezado
$_['heading_title'] = '¡Página no encontrada!';

// Texto
$_['text_not_found'] = '¡No se pudo encontrar la página que está buscando! Póngase en contacto con su administrador si el problema persiste.';
