<?php
// encabezado
$_['heading_title'] = 'Captcha';

// Texto
$_['text_success'] = 'Éxito: ¡Has modificado el Captcha!';
$_['text_list'] = 'Lista de Captchas';

// Columna
$_['column_name'] = 'Nombre de Captcha';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tienes permiso para modificar el captcha!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
