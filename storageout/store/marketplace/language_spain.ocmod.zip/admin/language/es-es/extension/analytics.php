<?php
// encabezado
$_['heading_title'] = 'Análisis';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado los análisis!';
$_['text_list'] = 'Lista de análisis';

// Columna
$_['column_name'] = 'Nombre del análisis';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar los análisis!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
