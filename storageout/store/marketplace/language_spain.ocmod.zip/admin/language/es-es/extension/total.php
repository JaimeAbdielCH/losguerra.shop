<?php
// encabezado
$_['heading_title'] = 'Total del pedido';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado el monto total!';

// Columna
$_['column_name'] = 'Cantidad total';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Ordenar';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el monto total!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
