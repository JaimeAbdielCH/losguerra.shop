<?php
// encabezado
$_['heading_title'] = 'Tipos de cambio';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado los tipos de cambio!';
$_['text_list'] = 'Lista de tipos de cambio';

// Columna
$_['column_name'] = 'Nombre de la tasa de cambio';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar los tipos de cambio!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
