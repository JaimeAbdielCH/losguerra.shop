<?php
// Título del encabezado
$_['heading_title'] = 'Werbung';
