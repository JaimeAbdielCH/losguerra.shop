<?php
// encabezado
$_['heading_title'] = 'Panel';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado el Tablero!';
$_['text_list'] = 'Lista del panel';

// Columna
$_['column_name'] = 'Nombre del tablero';
$_['column_width'] = 'Ancho';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Ordenar';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el tablero!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
