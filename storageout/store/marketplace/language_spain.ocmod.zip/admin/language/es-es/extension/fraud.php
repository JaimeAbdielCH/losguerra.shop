<?php
// encabezado
$_['heading_title'] = 'Antifraude';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado Antifraude!';
$_['text_list'] = 'Lista Antifraude';

// Columna
$_['column_name'] = 'Nombre antifraude';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar Antifraude!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
