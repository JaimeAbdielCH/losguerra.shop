<?php
// encabezado
$_['heading_title'] = 'Plantillas';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado las plantillas!';

// Columna
$_['column_name'] = 'Nombre de la plantilla';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar plantillas!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
