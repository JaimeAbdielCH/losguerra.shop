<?php
// encabezado
$_['heading_title'] = 'Métodos de pago';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado los métodos de pago!';
$_['text_list'] = 'Lista de métodos de pago';

// Columna
$_['column_name'] = 'Métodos de pago';
$_['column_vendor'] = 'Vendedor';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Ordenar';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar los métodos de pago!';
$_['error_extension'] = 'Advertencia: ¡La extensión no existe!';
