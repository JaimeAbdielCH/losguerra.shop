<?php
// Texto
$_['text_recommended'] = 'Recomendado';
$_['text_install'] = 'Instalar';
$_['text_uninstall'] = 'Desinstalar';
$_['text_delete'] = 'Borrar';
