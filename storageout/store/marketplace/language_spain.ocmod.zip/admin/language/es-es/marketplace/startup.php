<?php
// encabezado
$_['heading_title'] = 'Inicio';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado el inicio!';
$_['text_list'] = 'Lista de inicio';

// Columna
$_['column_code'] = 'Código de inicio';
$_['column_sort_order'] = 'Ordenar';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el inicio!';
