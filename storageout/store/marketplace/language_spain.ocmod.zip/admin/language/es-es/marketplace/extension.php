<?php
// encabezado
$_['heading_title'] = 'Extensiones';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado las extensiones!';
$_['text_list'] = 'Lista de extensiones';
$_['text_type'] = 'Elija el tipo de extensión';
$_['text_filter'] = 'Filtro';
