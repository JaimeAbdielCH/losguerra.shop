<?php
// errores
$_['error_extension'] = 'Advertencia: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_recurring'] = 'Advertencia: ¡el método de pago no tiene un método de pago recurrente!';
$_['error_payment'] = 'Advertencia: ¡No se pudo encontrar el método de pago %s!';
