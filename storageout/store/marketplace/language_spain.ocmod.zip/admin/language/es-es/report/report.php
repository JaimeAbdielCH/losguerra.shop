<?php
// encabezado
$_['heading_title'] = 'Informes';

// Texto
$_['text_success'] = 'Éxito: ¡Ha modificado los informes!';
$_['text_type'] = 'Elija el tipo de informe';
$_['text_filter'] = 'Filtro';
