<?php
// Título
$_['heading_title'] = 'Panel';
