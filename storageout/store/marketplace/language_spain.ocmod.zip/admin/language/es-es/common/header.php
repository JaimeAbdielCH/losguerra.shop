<?php
// encabezado
$_['heading_title'] = 'Administración de OpenCart';

// Texto
$_['text_notification'] = 'Notificaciones';
$_['text_notification_all'] = 'Mostrar todo';
$_['text_notification_none'] = 'Sin notificaciones';
$_['text_profile'] = 'Tu perfil';
$_['text_store'] = 'Tienda online (tienda)';
$_['text_help'] = 'Ayuda';
$_['text_homepage'] = 'Página de inicio de OpenCart';
$_['text_support'] = 'Foro de soporte';
$_['text_documentation'] = 'Documentación';
$_['text_logout'] = 'Cerrar sesión';
