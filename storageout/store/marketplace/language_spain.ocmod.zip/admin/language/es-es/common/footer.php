<?php
// Texto
$_['text_footer'] = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Reservados todos los derechos.';
$_['text_version'] = 'Versión %s';
