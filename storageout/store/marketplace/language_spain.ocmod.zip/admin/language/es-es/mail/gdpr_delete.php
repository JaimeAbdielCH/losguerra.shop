<?php
// Texto
$_['text_subject'] = '%s - ¡Su solicitud de RGPD ha sido procesada!';
$_['text_request'] = 'Solicitud de eliminación de cuenta';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_delete'] = 'Su solicitud de eliminación de datos GDPR ahora está completa.';
$_['text_contact'] = 'Para más información puede ponerse en contacto con el contacto de servicio de la tienda (tienda) aquí:';
$_['text_thanks'] = 'Gracias,';

// botones
$_['button_contact'] = 'Contáctenos';
