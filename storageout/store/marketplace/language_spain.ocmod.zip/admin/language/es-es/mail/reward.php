<?php
// Texto
$_['text_subject'] = '%s - Puntos de recompensa';
$_['text_received'] = '¡Ha recibido %s puntos de recompensa!';
$_['text_total'] = 'El total de sus puntos de recompensa ahora es %s.';
