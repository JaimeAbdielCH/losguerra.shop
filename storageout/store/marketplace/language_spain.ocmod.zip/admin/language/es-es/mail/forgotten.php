<?php
// Texto
$_['text_subject'] = '%s - Solicitud de restablecimiento de contraseña';
$_['text_greeting'] = 'Se ha solicitado una nueva contraseña para administrar %s.';
$_['text_change'] = 'Para restablecer su contraseña, haga clic en el siguiente enlace:';
$_['text_ip'] = 'La IP utilizada para esta solicitud:';
