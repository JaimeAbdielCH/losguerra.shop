<?php
// Texto
$_['text_subject'] = '%s - Crédito de afiliado';
$_['text_received'] = '¡Ha recibido %s de crédito!';
$_['text_total'] = 'Su saldo total ahora es %s.';
$_['text_credit'] = 'Su crédito puede usarse para su próxima compra.';
