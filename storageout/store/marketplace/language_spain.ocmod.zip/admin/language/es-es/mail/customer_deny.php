<?php
// Texto
$_['text_subject'] = '%s - ¡Su cuenta de cliente ha sido rechazada!';
$_['text_welcome'] = '¡Bienvenido y gracias por registrarse con %s!';
$_['text_denied'] = 'Lo sentimos, su solicitud fue denegada. Para obtener más información, puede comunicarse con el contacto de servicio de la tienda (tienda) aquí:';
$_['text_thanks'] = 'Gracias,';

// botones
$_['button_contact'] = 'Contáctenos';
