<?php
// Texto
$_['text_success'] = 'Éxito: ¡Ha procesado los créditos de regalo!';
$_['text_subject'] = 'Recibió un certificado de regalo de %s';
$_['text_greeting'] = 'Felicitaciones, ha recibido un vale de regalo por valor de %s.';
$_['text_from'] = 'Esta tarjeta de regalo le fue enviada por %s';
$_['text_message'] = 'Con un mensaje que lee';
$_['text_redeem'] = 'Para canjear este certificado de regalo, escriba el código de canje <b>%s</b>, haga clic en el enlace a continuación y compre el producto para el que desea usar el cupón. Puede ingresar el código del cupón de regalo en la página del carrito de compras antes de finalizar la compra.';
$_['text_footer'] = 'Por favor, responda a este correo electrónico si tiene alguna pregunta.';
$_['text_sent'] = 'Exitoso: ¡Se envió el correo electrónico con la tarjeta de regalo!';
