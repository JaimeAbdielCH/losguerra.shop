<?php
// Texto
$_['text_subject'] = '%s - ¡Su cuenta de afiliado ha sido activada!';
$_['text_welcome'] = '¡Bienvenido y gracias por registrarse con %s!';
$_['text_login'] = 'Su cuenta de afiliado ahora ha sido aprobada y puede iniciar sesión con su dirección de correo electrónico y contraseña visitando nuestro sitio web o la siguiente URL:';
$_['text_service'] = 'Después de iniciar sesión, puede generar códigos de seguimiento, realizar un seguimiento de los pagos de comisiones y editar la información de su cuenta.';
$_['text_thanks'] = 'Gracias,';
