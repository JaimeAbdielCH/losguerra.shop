<?php
// Texto
$_['text_subject'] = 'Intentos de restablecer código de seguridad';
$_['text_reset'] = 'Alguien ingresó el código de seguridad incorrectamente más de 3 veces.';
$_['text_link'] = 'Haga clic en el siguiente enlace para restablecer la seguridad de la cuenta:';
$_['text_ip'] = 'IP:';
$_['text_regards'] = 'Saludos cordiales';
