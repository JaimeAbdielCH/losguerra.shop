<?php
// Texto
$_['text_subject'] = '%s - Actualización de mercancías devueltas %s';
$_['text_return_id'] = 'ID de devolución:';
$_['text_date_added'] = 'Fecha de devolución:';
$_['text_return_status'] = 'Su solicitud de devolución ha sido actualizada al siguiente estado:';
$_['text_comment'] = 'Los comentarios para su devolución son:';
$_['text_footer'] = 'Por favor, responda a este correo electrónico si tiene alguna pregunta.';
