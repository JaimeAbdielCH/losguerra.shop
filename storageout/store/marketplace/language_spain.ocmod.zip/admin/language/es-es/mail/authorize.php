<?php
// Texto
$_['text_subject'] = 'Seguridad';
$_['text_code'] = 'Debe ingresar el código de seguridad en el control de seguridad del administrador.';
$_['text_ip'] = 'IP:';
$_['text_regards'] = 'Saludos cordiales';
