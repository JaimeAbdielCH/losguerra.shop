<?php
// Texto
$_['text_subject'] = '%s - Solicitud de RGPD aprobada!';
$_['text_request'] = 'Solicitud de eliminación de cuenta';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_gdpr'] = 'Su solicitud de eliminación de datos de GDPR ha sido aprobada y se ejecutará en <strong>%s días</strong>.';
$_['text_q'] = 'Pregunta: ¿Por qué no eliminamos sus datos de inmediato?';
$_['text_a'] = 'Respuesta: Las solicitudes de eliminación de cuenta se procesarán después de <strong>%s días</strong> para permitir que se procesen los reembolsos, contracargos o investigaciones de fraude.';
$_['text_delete'] = 'Recibirá un correo electrónico notificándole que su cuenta ha sido eliminada.';
$_['text_thanks'] = 'Gracias,';
