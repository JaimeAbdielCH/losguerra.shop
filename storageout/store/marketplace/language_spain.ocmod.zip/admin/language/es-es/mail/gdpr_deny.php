<?php
// Texto
$_['text_subject'] = '%s - ¡Su solicitud de GDPR fue denegada!';
$_['text_export'] = 'Solicitud para exportar datos de cuenta';
$_['text_remove'] = 'Solicitud de eliminación de cuenta';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_contact'] = 'Lo sentimos, su solicitud ha sido rechazada. Para obtener más información, puede comunicarse con el contacto de servicio de la tienda (tienda) aquí:';
$_['text_thanks'] = 'Gracias,';

// botones
$_['button_contact'] = 'Contáctenos';
