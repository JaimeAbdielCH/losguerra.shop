<?php
// Texto
$_['text_subject'] = '%s - ¡Su cuenta de cliente ha sido activada!';
$_['text_welcome'] = '¡Bienvenido y gracias por registrarse con %s!';
$_['text_login'] = 'Su cuenta de cliente ahora ha sido creada y puede iniciar sesión con su dirección de correo electrónico y contraseña visitando nuestro sitio web o la siguiente URL:';
$_['text_service'] = 'Después de iniciar sesión, puede acceder a servicios adicionales como B. revisar pedidos anteriores, imprimir facturas y procesar la información de su cuenta.';
$_['text_thanks'] = 'Gracias,';

// botones
$_['button_login'] = 'Iniciar sesión';
