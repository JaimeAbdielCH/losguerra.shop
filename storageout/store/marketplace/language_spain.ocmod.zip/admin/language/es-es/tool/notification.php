<?php
// encabezado
$_['heading_title'] = 'Notificaciones';

// Texto
$_['text_success'] = 'Éxito: ¡Has modificado las notificaciones!';
$_['text_list'] = 'Lista de notificaciones';

// Columna
$_['column_message'] = 'Mensaje';
$_['column_action'] = 'Acción';

// errores
$_['error_permission'] = 'Advertencia: ¡No tienes permiso para modificar notificaciones!';
