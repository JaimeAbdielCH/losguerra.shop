<?php
// 标题
$_['heading_title'] = '批准被拒绝！';

// 文本
$_['text_permission'] = '您没有访问此页面的权限。 请联系您的系统管理员。';
