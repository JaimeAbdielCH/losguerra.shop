<?php
//标题
$_['heading_title'] = '运费';

// 文本
$_['text_success'] = '成功：您已修改运费！';
$_['text_list'] = '发货清单';

// 柱子
$_['column_name'] = '送货方式';
$_['column_status'] = '状态';
$_['column_sort_order'] = '排序';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改运费的权限！';
$_['error_extension'] = '警告：扩展名不存在！';
