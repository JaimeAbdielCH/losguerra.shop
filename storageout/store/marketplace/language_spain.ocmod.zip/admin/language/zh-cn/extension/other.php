<?php
// 标题
$_['heading_title'] = '更多扩展';

// 文本
$_['text_success'] = '成功：您修改了更多扩展！';
$_['text_list'] = '附加扩展列表';

// 柱子
$_['column_name'] = '其他扩展名';
$_['column_status'] = '状态';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您无权修改其他扩展！';
$_['error_extension'] = '警告：扩展名不存在！';
