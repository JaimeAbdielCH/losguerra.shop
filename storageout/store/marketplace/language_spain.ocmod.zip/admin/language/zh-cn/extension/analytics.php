<?php
// 标题
$_['heading_title'] = '分析';

// 文本
$_['text_success'] = '成功：您已修改分析！';
$_['text_list'] = '分析列表';

// 柱子
$_['column_name'] = '分析名称';
$_['column_status'] = '状态';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改分析的权限！';
$_['error_extension'] = '警告：扩展名不存在！';
