<?php
// 标题
$_['heading_title'] = '提要';

// 文本
$_['text_success'] = '成功：您已修改提要！';
$_['text_list'] = '提要列表';

// 柱子
$_['column_name'] = '提要名称';
$_['column_status'] = '状态';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改提要的权限！';
$_['error_extension'] = '警告：扩展名不存在！';
