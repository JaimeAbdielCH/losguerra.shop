<?php
// 标题
$_['heading_title'] = '反欺诈';

// 文本
$_['text_success'] = '成功：您已修改反欺诈！';
$_['text_list'] = '反欺诈列表';

// 柱子
$_['column_name'] = '反欺诈名称';
$_['column_status'] = '状态';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改反欺诈的权限！';
$_['error_extension'] = '警告：扩展名不存在！';
