<?php
// 标题
$_['heading_title'] = '支付方式';

// 文本
$_['text_success'] = '成功：您已修改支付方式！';
$_['text_list'] = '支付方式列表';

// 柱子
$_['column_name'] = '支付方式';
$_['column_vendor'] = '供应商';
$_['column_status'] = '状态';
$_['column_sort_order'] = '排序';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改支付方式的权限！';
$_['error_extension'] = '警告：扩展名不存在！';
