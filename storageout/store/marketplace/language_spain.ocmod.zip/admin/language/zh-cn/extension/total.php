<?php
//标题
$_['heading_title'] = '订单总计';

// 文本
$_['text_success'] = '成功：您已修改总金额！';

// 柱子
$_['column_name'] = '总金额';
$_['column_status'] = '状态';
$_['column_sort_order'] = '排序';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您无权修改总金额！';
$_['error_extension'] = '警告：扩展名不存在！';
