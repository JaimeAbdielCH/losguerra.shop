<?php
// 标题
$_['heading_title'] = '报告';

// 文本
$_['text_success'] = '成功：您已修改报告！';
$_['text_type'] = '选择报告类型';
$_['text_filter'] = '过滤器';
