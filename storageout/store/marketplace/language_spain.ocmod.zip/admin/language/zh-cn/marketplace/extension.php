<?php
// 标题
$_['heading_title'] = '扩展名';

// 文本
$_['text_success'] = '成功：您已经修改了扩展！';
$_['text_list'] = '扩展列表';
$_['text_type'] = '选择扩展类型';
$_['text_filter'] = '过滤器';
