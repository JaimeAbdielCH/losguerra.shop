<?php
// 文本
$_['text_recommended'] = '推荐';
$_['text_install'] = '安装';
$_['text_uninstall'] = '卸载';
$_['text_delete'] = '删除';
