<?php
// 标题
$_['heading_title'] = '启动';

// 文本
$_['text_success'] = '成功：您已修改启动！';
$_['text_list'] = '启动列表';

// 柱子
$_['column_code'] = '启动代码';
$_['column_sort_order'] = '排序';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改启动的权限！';
