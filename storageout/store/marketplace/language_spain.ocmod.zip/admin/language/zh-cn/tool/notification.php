<?php
// 标题
$_['heading_title'] = '通知';

// 文本
$_['text_success'] = '成功：您已修改通知！';
$_['text_list'] = '通知列表';

// 柱子
$_['column_message'] = '消息';
$_['column_action'] = '动作';

// 错误
$_['error_permission'] = '警告：您没有修改通知的权限！';
