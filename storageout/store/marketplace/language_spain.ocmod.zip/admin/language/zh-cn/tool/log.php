<?php
// 标题
$_['heading_title'] = '错误日志信息';

// 文本
$_['text_success'] = '成功：您已成功清除错误日志信息！';
$_['text_list'] = '错误日志日志';

// 错误
$_['error_permission'] = '警告：您没有权限删除错误日志信息！';
$_['error_file'] = '警告：找不到文件 %s！';
$_['error_size'] = '警告：错误日志文件 %s 是 %s 大！';
$_['error_empty'] = '警告：错误日志文件 %s 为空！';
