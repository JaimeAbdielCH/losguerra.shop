<?php
// 文本
$_['text_footer']  = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' 版权所有。';
$_['text_version'] = '版本 %s';
