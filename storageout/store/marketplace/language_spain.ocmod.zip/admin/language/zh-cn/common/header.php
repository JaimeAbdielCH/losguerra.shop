<?php
// 标题
$_['heading_title'] = 'OpenCart 管理';

// 文本
$_['text_notification'] = '通知';
$_['text_notification_all'] = '显示全部';
$_['text_notification_none'] = '没有通知';
$_['text_profile'] = '你的个人资料';
$_['text_store'] = '在线商店（store）';
$_['text_help'] = '帮助';
$_['text_homepage'] = 'OpenCart 主页';
$_['text_support'] = '支持论坛';
$_['text_documentation'] = '文档';
$_['text_logout'] = '注销';
