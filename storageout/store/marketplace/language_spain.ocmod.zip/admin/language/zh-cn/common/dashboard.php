<?php
// 标题
$_['heading_title'] = '仪表板';
