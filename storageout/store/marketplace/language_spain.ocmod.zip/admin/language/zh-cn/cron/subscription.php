<?php
// 错误
$_['error_extension'] = '警告：找不到付款方式扩展！';
$_['error_recurring'] = '警告：付款方式没有循环付款方式！';
$_['error_payment'] = '警告：无法找到付款方式 %s！';
