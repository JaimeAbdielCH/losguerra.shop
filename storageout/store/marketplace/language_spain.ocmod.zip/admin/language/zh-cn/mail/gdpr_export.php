<?php
// 文本
$_['text_subject'] = '%s - GDPR 导出作业完成！';
$_['text_request'] = '导出个人数据';
$_['text_hello'] = '你好 <strong>%s</strong>,';
$_['text_user'] = '用户';
$_['text_gdpr'] = '您的 GDPR 订单现已完成。 以下是您的 GDPR 数据。';
$_['text_account'] = '客户账户';
$_['text_customer'] = '个人资料';
$_['text_address'] = '地址';
$_['text_addresses'] = '地址';
$_['text_name'] = '客户姓名';
$_['text_recipient'] = '收件人';
$_['text_email'] = '电子邮件';
$_['text_telephone'] = '电话';
$_['text_company'] = '公司';
$_['text_address_1'] = '地址';
$_['text_address_2'] = '地址补充';
$_['text_postcode'] = '邮编';
$_['text_city'] = '城市';
$_['text_country'] = '国家';
$_['text_zone'] = '地区/州';
$_['text_history'] = '登录历史';
$_['text_ip'] = 'IP';
$_['text_date_added'] = '添加日期';
$_['text_thanks'] = '谢谢';
