<?php
// 文本
$_['text_subject'] = '重置安全密码尝试';
$_['text_reset'] = '有人错误输入安全码超过 3 次。';
$_['text_link'] = '点击下面的链接重置账户安全：';
$_['text_ip'] = 'IP:';
$_['text_regards'] = '最好的问候';
