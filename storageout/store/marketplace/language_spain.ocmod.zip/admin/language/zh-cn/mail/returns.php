<?php
// 文本
$_['text_subject'] = '%s - 退货更新 %s';
$_['text_return_id'] = '返回 ID：';
$_['text_date_added'] = '返回日期：';
$_['text_return_status'] = '您的退货请求已更新为以下状态：';
$_['text_comment'] = '您的退货评论是：';
$_['text_footer'] = '如果您有任何问题，请回复此邮件。';
