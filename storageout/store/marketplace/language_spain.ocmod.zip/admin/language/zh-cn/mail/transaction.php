<?php
// 文本
$_['text_subject'] = '%s - 联属信用';
$_['text_received'] = '您已收到 %s 积分！';
$_['text_total'] = '您的总余额现在是 %s。';
$_['text_credit'] = '您的积分可用于下次购买。';
