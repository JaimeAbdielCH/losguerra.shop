<?php
// 文本
$_['text_subject'] = '%s - 密码重置请求';
$_['text_greeting'] = '已请求一个新密码来管理 %s。';
$_['text_change'] = '要重设密码，请点击以下链接：';
$_['text_ip'] = '本次请求使用的IP：';
