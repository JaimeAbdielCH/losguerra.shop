<?php
// 文本
$_['text_subject'] = '%s - GDPR 请求已获批准！';
$_['text_request'] = '账号删除请求';
$_['text_hello'] = '你好 <strong>%s</strong>,';
$_['text_user'] = '用户';
$_['text_gdpr'] = '您的 GDPR 数据删除请求已获批准，并将在 <strong>%s 天</strong>后执行。';
$_['text_q'] = '问题：我们为什么不立即删除您的数据？';
$_['text_a'] = '回答：帐户删除请求将在 <strong>%s 天</strong> 后处理，以便处理任何退款、拒付或欺诈调查。';
$_['text_delete'] = '您将收到一封电子邮件，通知您您的帐户已被删除。';
$_['text_thanks'] = '谢谢';
