<?php
// 文本
$_['text_subject'] = '%s - 奖励积分';
$_['text_received'] = '您已获得 %s 奖励积分！';
$_['text_total'] = '您的总奖励积分现在是 %s。';
