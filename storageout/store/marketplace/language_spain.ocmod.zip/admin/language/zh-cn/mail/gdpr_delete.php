<?php
// 文本
$_['text_subject'] = '%s - 您的 GDPR 请求已被处理！';
$_['text_request'] = '账号删除请求';
$_['text_hello'] = '你好 <strong>%s</strong>,';
$_['text_user'] = '用户';
$_['text_delete'] = '您的 GDPR 数据删除请求现已完成。';
$_['text_contact'] = '欲了解更多信息，您可以在此处与商店（商店）服务联系人取得联系：';
$_['text_thanks'] = '谢谢';

// 纽扣
$_['button_contact'] = '联系我们';
