<?php
// 文本
$_['text_subject'] = '%s - 你的 GDPR 请求被拒绝了！';
$_['text_export'] = '请求导出账户数据';
$_['text_remove'] = '账号删除请求';
$_['text_hello'] = '你好 <strong>%s</strong>,';
$_['text_user'] = '用户';
$_['text_contact'] = '抱歉，您的请求已被拒绝。 欲了解更多信息，您可以在这里联系商店（商店）服务联系方式：';
$_['text_thanks'] = '谢谢';

// 纽扣
$_['button_contact'] = '联系我们';
