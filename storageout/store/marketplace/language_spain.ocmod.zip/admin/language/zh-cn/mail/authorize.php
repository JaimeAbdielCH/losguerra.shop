<?php
// 文本
$_['text_subject'] = '安全';
$_['text_code'] = '您必须在管理员安全检查中输入安全代码。';
$_['text_ip'] = 'IP:';
$_['text_regards'] = '最好的问候';
