<?php
// Heading
$_['heading_title']    = '取件 (Pickup)';

// Text
$_['text_description'] = '取件 (Pickup)';
