<?php
// Text
$_['text_low_order_fee'] = '最低数量附加费';
