<?php
// 文本
$_['text_sub_total'] = '小计（净额）';
