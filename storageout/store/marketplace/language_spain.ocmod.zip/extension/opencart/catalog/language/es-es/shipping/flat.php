<?php
// encabezado
$_['heading_title'] = 'Cantidad fija de envío';

// Texto
$_['text_description'] = 'Tarifa plana de envío';
