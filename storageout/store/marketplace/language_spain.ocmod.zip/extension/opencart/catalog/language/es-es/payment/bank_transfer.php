<?php
// encabezado
$_['heading_title'] = 'Transferencia bancaria';

// Texto
$_['text_instruction'] = 'Instrucciones de transferencia bancaria';
$_['text_description'] = 'Transfiera el monto total a la siguiente cuenta bancaria:';
$_['text_payment'] = 'Su pedido solo se enviará después de que hayamos recibido su pago.';
