<?php
// Título
$_['heading_title'] = 'Categorías';
