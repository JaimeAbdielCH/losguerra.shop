<?php
// encabezado
$_['heading_title'] = 'Elegir tienda online';

// Texto
$_['text_default'] = 'Predeterminado';
$_['text_store'] = 'Seleccione la tienda en línea (tienda) que desea visitar.';
