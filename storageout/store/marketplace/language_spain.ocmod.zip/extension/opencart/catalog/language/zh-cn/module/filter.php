<?php
// 标题
$_['heading_title'] = '限制搜索';
