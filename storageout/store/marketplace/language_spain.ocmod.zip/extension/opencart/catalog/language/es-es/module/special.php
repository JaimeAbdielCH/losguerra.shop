<?php
// encabezado
$_['heading_title'] = 'Ofertas especiales actuales';
