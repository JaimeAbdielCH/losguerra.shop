<?php
// 文本
$_['text_credit'] = '在线商店（商店）信用';
$_['text_order_id'] = '订单号.: #%s';
