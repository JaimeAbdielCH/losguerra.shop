<?php
// 标题
$_['heading_title'] = '选择网店';

// 文本
$_['text_default'] = '默认';
$_['text_store'] = '请选择您要访问的网上商店（商店）。';
