<?php
// 标题
$_['heading_title'] = '银行转账';

// 文本
$_['text_instruction'] = '银行转账说明';
$_['text_description'] = '请将总金额转入以下银行账户：';
$_['text_payment'] = '您的订单只有在我们收到您的付款后才会发货。';
