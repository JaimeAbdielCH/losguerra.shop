<?php
// Texto
$_['text_sub_total'] = 'Subtotal (neto)';
