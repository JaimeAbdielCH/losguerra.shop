<?php
// 标题
$_['heading_title'] = '当前畅销书';
