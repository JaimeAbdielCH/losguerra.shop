<?php
// 标题
$_['heading_title'] = '信息';

// 文本
$_['text_contact'] = '联系信息';
$_['text_sitemap'] = '站点地图';
