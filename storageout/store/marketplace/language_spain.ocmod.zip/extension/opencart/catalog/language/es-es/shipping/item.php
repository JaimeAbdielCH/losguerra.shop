<?php
// encabezado
$_['heading_title'] = 'Envío por unidad (Envío por piezas)';

// Texto
$_['text_description'] = 'Envío por unidad';
