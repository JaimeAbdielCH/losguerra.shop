<?php
// 文本
$_['text_handling'] = '手续费';
