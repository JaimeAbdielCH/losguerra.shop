<?php
// 标题
$_['heading_title'] = '使用礼券';

// 文本
$_['text_voucher'] = '礼券（%s）';
$_['text_success'] = '成功：您的礼品卡已被应用！';
$_['text_remove'] = '成功：您的礼品卡已被移除！';

// 入口
$_['entry_voucher'] = '在此输入您的礼券代码';

// 错误
$_['error_voucher'] = '警告：礼券无效或余额已被使用！';
$_['error_status'] = '警告：注意！ 本店不激活礼券！';
