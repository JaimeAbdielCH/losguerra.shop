<?php
// 标题
$_['heading_title'] = '新产品';
