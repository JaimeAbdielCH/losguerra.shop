<?php
// encabezado
$_['heading_title'] = 'Pago Gratis';
