<?php
// 标题
$_['heading_title'] = '客户账户';

// 文本
$_['text_register'] = '新注册';
$_['text_login'] = '登录';
$_['text_logout'] = '注销';
$_['text_forgotten'] = '忘记密码';
$_['text_account'] = '管理客户账户';
$_['text_edit'] = '编辑个人账户信息';
$_['text_password'] = '更改密码';
$_['text_address'] = '管理地址簿';
$_['text_wishlist'] = '编辑愿望清单';
$_['text_order'] = '查看订单';
$_['text_download'] = '管理下载';
$_['text_reward'] = '显示奖励积分';
$_['text_return'] = '管理退货';
$_['text_transaction'] = '显示金融交易';
$_['text_newsletter'] = '管理时事通讯';
$_['text_subscription'] = '管理订阅';
