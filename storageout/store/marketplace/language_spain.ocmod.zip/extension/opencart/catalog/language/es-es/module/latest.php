<?php
// Título
$_['heading_title'] = 'Nuevo Producto';
