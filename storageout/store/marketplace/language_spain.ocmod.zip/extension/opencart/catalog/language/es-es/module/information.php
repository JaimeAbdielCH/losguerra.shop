<?php
// Título
$_['heading_title'] = 'Información';

// Texto
$_['text_contact'] = 'Información de contacto';
$_['text_sitemap'] = 'Mapa del sitio';
