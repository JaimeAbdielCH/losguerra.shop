<?php
// 标题
$_['heading_title'] = '免费送货';

// 文本
$_['text_description'] = '免费送货';
