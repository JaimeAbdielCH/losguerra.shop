<?php
// encabezado
$_['heading_title'] = 'Restringir búsqueda';
