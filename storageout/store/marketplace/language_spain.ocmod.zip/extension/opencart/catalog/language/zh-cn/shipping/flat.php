<?php
// 标题
$_['heading_title'] = '固定运费';

// 文本
$_['text_description'] = '统一运费';
