<?php
// 标题
$_['heading_title'] = '货到付款/货到付款';

// 错误
$_['error_order_id'] = '没有订单号。 在会议中！';
$_['error_payment_method'] = '付款方式不正确！';
