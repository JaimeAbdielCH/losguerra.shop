<?php
// 文本
$_['text_captcha'] = '验证码';

// 入口
$_['entry_captcha'] = '在下面的框中输入图片中的验证码。';

// 错误
$_['error_captcha'] = '输入的验证码与图片显示不符！';
