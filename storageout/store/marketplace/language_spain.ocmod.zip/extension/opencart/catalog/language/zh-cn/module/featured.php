<?php
// Heading
$_['heading_title'] = '建议';
