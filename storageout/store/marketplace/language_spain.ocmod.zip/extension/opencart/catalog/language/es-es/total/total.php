<?php
// Texto
$_['text_total'] = 'Importe total (bruto)';
