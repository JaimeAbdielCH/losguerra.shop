<?php
// Texto
$_['text_captcha'] = 'Captcha';

// Entrada
$_['entry_captcha'] = 'Ingrese el código de la imagen en el cuadro de abajo.';

// errores
$_['error_captcha'] = '¡El código de verificación ingresado no coincide con la visualización de la imagen!';
