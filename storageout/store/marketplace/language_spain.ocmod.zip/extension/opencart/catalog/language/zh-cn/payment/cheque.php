<?php
// 标题
$_['heading_title'] = '支票/汇票';

// 文本
$_['text_instruction'] = '支票/汇票指示';
$_['text_payable'] = '支付给：';
$_['text_address'] = '发送至：';
$_['text_payment'] = '您的订单只有在我们收到您的付款后才会发货。';
