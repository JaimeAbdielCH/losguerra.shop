<?php
// encabezado
$_['heading_title'] = 'Recoger (Recoger)';

// Texto
$_['text_description'] = 'Recoger';
