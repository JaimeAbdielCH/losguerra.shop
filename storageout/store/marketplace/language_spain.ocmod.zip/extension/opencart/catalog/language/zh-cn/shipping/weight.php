<?php
// 标题
$_['heading_title'] = '基于重量的运费';

// 文本
$_['text_weight'] = '重量：';
