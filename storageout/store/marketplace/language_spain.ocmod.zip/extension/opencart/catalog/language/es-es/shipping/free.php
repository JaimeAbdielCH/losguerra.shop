<?php
// encabezado
$_['heading_title'] = 'Envío gratis';

// Texto
$_['text_description'] = 'Envío gratis';
