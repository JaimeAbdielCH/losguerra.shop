<?php
// Texto
$_['text_handling'] = 'Tarifa de gestión';
