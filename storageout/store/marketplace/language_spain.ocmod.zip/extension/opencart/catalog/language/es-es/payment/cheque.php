<?php
// encabezado
$_['heading_title'] = 'Cheque / Giro Postal';

// Texto
$_['text_instruction'] = 'Instrucciones para cheques/giros postales';
$_['text_payable'] = 'Pagadero a: ';
$_['text_address'] = 'Enviar a: ';
$_['text_payment'] = 'Su pedido solo se enviará después de que hayamos recibido su pago.';
