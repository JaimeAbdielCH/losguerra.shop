<?php
// Texto
$_['text_credit'] = 'Tienda en línea (Tienda) Kredit';
$_['text_order_id'] = 'Bestell-Nr.: #%s';
