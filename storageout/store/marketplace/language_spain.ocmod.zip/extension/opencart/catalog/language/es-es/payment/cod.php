<?php
// encabezado
$_['heading_title'] = 'Contra reembolso / Pago contra reembolso';

// errores
$_['error_order_id'] = 'Sin ID de pedido. ¡en sesión!';
$_['error_payment_method'] = '¡El método de pago es incorrecto!';
