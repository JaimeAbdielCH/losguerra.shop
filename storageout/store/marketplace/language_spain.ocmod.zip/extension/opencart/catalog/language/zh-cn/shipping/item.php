<?php
// 标题
$_['heading_title'] = '每件运费（按件运费）';

// 文本
$_['text_description'] = '单位运费';
