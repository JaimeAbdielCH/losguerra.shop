<?php
// encabezado
$_['heading_title'] = 'Gastos de envío en función del peso';

// Texto
$_['text_weight'] = 'Peso:';
