<?php
// 文本
$_['text_total'] = '总金额（总额）';
