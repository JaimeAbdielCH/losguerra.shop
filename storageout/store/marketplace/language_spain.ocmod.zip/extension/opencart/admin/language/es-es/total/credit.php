<?php
// encabezado
$_['heading_title'] = 'Estado del saldo';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado los estados de crédito!';
$_['text_edit'] = 'Editar estado de crédito';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden de clasificación';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el estado del crédito!';
