<?php
// encabezado
$_['heading_title'] = 'Envío por unidad (Envío por piezas)';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado el envío por unidad!';
$_['text_edit'] = 'Editar envío por unidad';

// Entrada
$_['entry_cost'] = 'Coste';
$_['entry_tax_class'] = 'Categoría de impuestos';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Ordenar';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el envío por unidad!';
