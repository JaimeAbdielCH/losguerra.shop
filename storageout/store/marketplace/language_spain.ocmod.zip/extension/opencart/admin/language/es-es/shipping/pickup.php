<?php
// encabezado
$_['heading_title'] = 'Recoger (Recoger)';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado la recogida!';
$_['text_edit'] = 'Editar recogida';

// Entrada
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Ordenar';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar la recogida!';
