<?php
// encabezado
$_['heading_title'] = 'Pago contra reembolso';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado con éxito el pago contra reembolso!';
$_['text_edit'] = 'Editar pago contra reembolso';

// Entrada
$_['entry_order_status'] = 'Estado del pedido';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Ordenar';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el pago contra reembolso!';
