<?php
// encabezado
$_['heading_title'] = 'Usando un código de cupón (vale de descuento)';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado usando un código de cupón!';
$_['text_edit'] = 'Editar el uso de un código de cupón';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden de clasificación';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el uso de un código de cupón!';
