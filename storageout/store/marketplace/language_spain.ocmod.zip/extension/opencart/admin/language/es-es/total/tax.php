<?php
// encabezado
$_['heading_title'] = 'Impuesto';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado el impuesto!';
$_['text_edit'] = 'Editar impuesto';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden de clasificación';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar impuestos!';
