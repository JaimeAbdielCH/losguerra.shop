<?php
// encabezado
$_['heading_title'] = 'Cantidad total';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado el monto total!';
$_['text_edit'] = 'Editar total';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden de clasificación';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el monto total!';
