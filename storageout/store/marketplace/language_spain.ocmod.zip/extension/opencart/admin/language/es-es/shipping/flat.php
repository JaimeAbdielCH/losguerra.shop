<?php
// encabezado
$_['heading_title'] = 'Tarifa plana de envío';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado la tarifa plana de envío!';
$_['text_edit'] = 'Editar el importe de envío de tarifa plana';

// Entrada
$_['entry_cost'] = 'Cuota de entrada';
$_['entry_tax_class'] = 'Categoría de impuestos';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Ordenar';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar la tarifa plana de envío!';
