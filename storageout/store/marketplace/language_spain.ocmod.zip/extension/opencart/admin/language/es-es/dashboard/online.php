<?php
// encabezado
$_['heading_title'] = 'Actualmente en línea';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado Dashboard Aktuell Online!';
$_['text_edit'] = 'Editar panel actualmente en línea';
$_['text_view'] = 'Mostrar más...';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden de clasificación';
$_['entry_width'] = 'Ancho';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el panel actualmente en línea!';
