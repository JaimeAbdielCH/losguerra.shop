<?php
// encabezado
$_['heading_title'] = 'Información';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de información!';
$_['text_edit'] = 'Editar módulo de información';

// Entrada
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el módulo de información!';
