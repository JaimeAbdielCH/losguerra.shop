<?php
// encabezado
$_['heading_title'] = 'Categorías';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de categorías!';
$_['text_edit'] = 'Editar Módulo de Categorías';

// Entrada
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tienes permiso para modificar el módulo de categorías!';
