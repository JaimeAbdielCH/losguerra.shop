<?php
// encabezado
$_['heading_title'] = 'Cuenta de cliente';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado el módulo de cuenta de cliente!';
$_['text_edit'] = 'Editar módulo de cuenta de cliente';

// Entrada
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el módulo de cuenta de cliente!';
