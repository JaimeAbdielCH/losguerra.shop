<?php
// encabezado
$_['heading_title'] = 'Plantilla predeterminada (tema)';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado la plantilla estándar!';
$_['text_edit'] = 'Editar plantilla predeterminada';

// Entrada
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar la plantilla predeterminada!';
