<?php
// encabezado
$_['heading_title'] = 'Captcha básico (versión simple)';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el Captcha básico!';
$_['text_edit'] = 'Editar Captcha básico';

// Entrada
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el Captcha básico!';
