<?php
// encabezado
$_['heading_title'] = 'Módulo de Tiendas Online (Tiendas)';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de tiendas online (tiendas)!';
$_['text_edit'] = 'Editar módulo de tiendas online (tiendas)';

// Entrada
$_['entry_admin'] = 'Solo para administradores';
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tienes permiso para modificar el módulo de tiendas online (tiendas)!';
