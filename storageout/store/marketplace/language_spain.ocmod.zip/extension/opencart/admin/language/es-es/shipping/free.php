<?php
// encabezado
$_['heading_title'] = 'Envío gratis';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: Ha modificado ¡Envío gratis!';
$_['text_edit'] = 'Editar envío gratis';

// Entrada
$_['entry_total'] = 'Total';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Ordenar';

// Ayuda
$_['help_total'] = 'Se requiere el subtotal antes de que el módulo Envío gratuito esté disponible.';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar Envío Gratis!';
