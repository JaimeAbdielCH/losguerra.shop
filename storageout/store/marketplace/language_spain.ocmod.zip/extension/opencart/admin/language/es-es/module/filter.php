<?php
// encabezado
$_['heading_title'] = 'Filtro';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado el módulo de filtro!';
$_['text_edit'] = 'Editar módulo de filtro';

// Entrada
$_['entry_status'] = 'Estado';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar el módulo de filtro!';
