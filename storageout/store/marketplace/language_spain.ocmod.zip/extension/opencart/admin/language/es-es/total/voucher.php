<?php
// encabezado
$_['heading_title'] = 'Certificado de regalo';

// Texto
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Ha modificado la tarjeta de regalo!';
$_['text_edit'] = 'Editar tarjeta de regalo';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden de clasificación';

// errores
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar la tarjeta de regalo!';
