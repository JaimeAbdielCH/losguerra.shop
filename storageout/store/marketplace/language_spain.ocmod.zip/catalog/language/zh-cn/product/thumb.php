<?php
// 文本
$_['text_price'] = '价格/单位：';
$_['text_tax'] = '价格（净价）：';
