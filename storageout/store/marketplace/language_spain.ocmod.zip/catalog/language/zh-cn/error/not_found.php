<?php
// 标题
$_['heading_title'] = '找不到您请求的页面！';

// 文本
$_['text_error'] = '找不到您请求的页面！';
