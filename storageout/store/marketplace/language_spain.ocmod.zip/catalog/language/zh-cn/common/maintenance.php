<?php
// 标题
$_['heading_title'] = '维护';

// 文本
$_['text_maintenance'] = '维护模式';
$_['text_message'] = '<h1 style="text-align:center;">我们目前正在进行一些定期维护。 <br/>我们会尽快回来。 请稍后再回来查看。</h1>';
