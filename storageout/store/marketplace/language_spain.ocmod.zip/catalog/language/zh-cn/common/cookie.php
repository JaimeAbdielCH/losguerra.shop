<?php
// 文本
$_['text_success'] = '感谢您让我们知道您的选择！';
$_['text_cookie'] = '本网站使用 cookie。 如需更多信息，请<a href="%s" class="alert-link modal-link">单击此处</a>。';

// 纽扣
$_['button_agree'] = '同意！';
$_['button_disagree'] = '不，谢谢！';
