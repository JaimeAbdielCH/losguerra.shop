<?php
// 文本
$_['text_information'] = '信息';
$_['text_service'] = '客户服务';
$_['text_extra'] = '额外';
$_['text_contact'] = '联系方式';
$_['text_return'] = '退货';
$_['text_sitemap'] = '站点地图';
$_['text_gdpr'] = 'GDPR';
$_['text_manufacturer'] = '制造商和品牌';
$_['text_voucher'] = '礼券';
$_['text_affiliate'] = '联盟计划';
$_['text_special'] = '特别优惠';
$_['text_account'] = '我的账户';
$_['text_order'] = '查看订单';
$_['text_wishlist'] = '编辑愿望清单';
$_['text_newsletter'] = '管理时事通讯';
$_['text_powered'] = '由 <a href="https://www.opencart.com">OpenCart</a><br/> 提供支持 %s &copy; %s';
