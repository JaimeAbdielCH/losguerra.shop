<?php
// 文本
$_['text_language'] = '语言';
