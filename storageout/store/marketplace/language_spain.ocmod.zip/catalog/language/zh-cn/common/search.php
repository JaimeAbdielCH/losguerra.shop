<?php
// 文本
$_['text_search'] = '搜索';
