<?php
// 文本
$_['text_category'] = '类别';
$_['text_all'] = '显示全部';
