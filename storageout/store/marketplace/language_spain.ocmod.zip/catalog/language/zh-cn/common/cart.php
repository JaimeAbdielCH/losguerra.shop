<?php
// 文本
$_['text_items'] = '%s 项目 - %s';
$_['text_subscription'] = '订阅';
$_['text_subscription_trial'] = '%s 每 %d %s(s) 支付 %d 次然后 ';
$_['text_subscription_duration'] = '%s 每 %d %s(s) 支付 %d 次';
$_['text_subscription_cancel'] = '%s 每 %d %s(s) 直到终止';
$_['text_day'] = '天数';
$_['text_week'] = '周';
$_['text_semi_month'] = '14 天';
$_['text_month'] = '月份';
$_['text_year'] = '年份';
$_['text_no_results'] = '您的购物车是空的！';
$_['text_cart'] = '显示购物车';
$_['text_checkout'] = '结帐';
