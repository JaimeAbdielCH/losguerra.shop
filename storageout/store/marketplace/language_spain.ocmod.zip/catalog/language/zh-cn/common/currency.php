<?php
// 文本
$_['text_currency'] = '货币';
