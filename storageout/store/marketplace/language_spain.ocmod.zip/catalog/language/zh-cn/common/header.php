<?php
// 文本
$_['text_wishlist'] = '愿望清单 (%s)';
$_['text_shopping_cart'] = '购物车';
$_['text_account'] = '客户账户';
$_['text_register'] = '注册新的';
$_['text_login'] = '登录';
$_['text_order'] = '我的订单';
$_['text_transaction'] = '我的金融交易';
$_['text_download'] = '我的下载';
$_['text_logout'] = '注销';
$_['text_checkout'] = '结帐';
