<?php
// 标题
$_['heading_title'] = 'GDPR-成功';

// 文本
$_['text_account'] = '客户账户';
$_['text_export'] = '我们收到了导出您的帐户信息的请求。';
$_['text_remove'] = 'GDPR 帐户删除请求将在 <strong>%s 天</strong> 后处理，以便处理任何拒付、退款或欺诈调查。';
