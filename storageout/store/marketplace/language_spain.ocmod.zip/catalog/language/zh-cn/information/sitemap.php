<?php
// 标题
$_['heading_title'] = '站点地图';

// 文本
$_['text_special'] = '特别优惠';
$_['text_account'] = '我的客户账户';
$_['text_edit'] = '编辑客户账户';
$_['text_password'] = '更改密码';
$_['text_address'] = '管理地址簿';
$_['text_history'] = '查看订单';
$_['text_download'] = '管理下载';
$_['text_cart'] = '购物车';
$_['text_checkout'] = '结帐';
$_['text_search'] = '搜索';
$_['text_information'] = '信息';
$_['text_contact'] = '联系方式';
