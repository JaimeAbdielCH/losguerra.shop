<?php
// 文本
$_['text_subject'] = '%s - 请求重置您的密码';
$_['text_greeting'] = '已请求客户帐户 %s 的新密码。';
$_['text_change'] = '要重设密码，请点击以下链接：';
$_['text_ip'] = '本次请求使用的IP是：';

// 纽扣
$_['button_reset'] = '重置密码';
