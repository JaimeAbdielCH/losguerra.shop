<?php
// 文本
$_['text_subject'] = '%s - 产品评分';
$_['text_waiting'] = '一个新的产品评论正在等待处理。';
$_['text_product'] = '产品：';
$_['text_reviewer'] = '审稿人：';
$_['text_rating'] = '评分：';
$_['text_review'] = '评论详情：';
