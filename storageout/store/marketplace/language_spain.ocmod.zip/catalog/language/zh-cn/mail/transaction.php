<?php
// 文本
$_['text_subject'] = '%s - 联属佣金';
$_['text_received'] = '恭喜！ 您已收到来自 %s 联属网络营销计划的佣金；';
$_['text_amount'] = '您已收到：';
$_['text_total'] = '您现在的佣金总额是：';
