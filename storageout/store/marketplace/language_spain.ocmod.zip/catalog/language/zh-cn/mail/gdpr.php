<?php
// 文本
$_['text_subject'] = '%s - GDPR 导出/删除请求！';
$_['text_export'] = '请求数据导出';
$_['text_remove'] = '请求删除客户账户';
$_['text_gdpr'] = '来自此电子邮件地址的 GDPR 请求。 要确认此操作，请单击以下链接：';
$_['text_ip'] = '本次请求使用的IP是：';
$_['text_contact'] = '如果您还没有提交此请求，请在这里联系我们的工作人员：';
$_['text_thanks'] = '谢谢';
$_['text_ignore'] = '如果您还没有提交此请求，请忽略此邮件。';

// 纽扣
$_['button_export'] = '我确认导出我的数据';
$_['button_remove'] = '我确认删除我的客户账户';
