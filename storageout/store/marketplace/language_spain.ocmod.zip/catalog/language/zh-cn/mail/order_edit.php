<?php
// 文本
$_['text_subject'] = '%s - 更新您的订单 %s';
$_['text_order_id'] = '订单编号：';
$_['text_date_added'] = '订购日期：';
$_['text_order_status'] = '您的订单已更新为以下状态：';
$_['text_comment'] = '关于您订单的评论：';
$_['text_link'] = '要查看您的订单，请点击以下链接：';
$_['text_footer'] = '如果您有任何问题，请回复此邮件。';
