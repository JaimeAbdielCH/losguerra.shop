<?php
// 标题
$_['heading_title'] = '管理奖励积分';

// 柱子
$_['column_date_added'] = '操作日期';
$_['column_description'] = '描述';
$_['column_points'] = '积分';

// 文本
$_['text_account'] = '客户账户';
$_['text_reward'] = '编辑奖励积分';
$_['text_total'] = '您的奖励积分总数为：';
$_['text_no_results'] = '您的客户帐户没有奖励积分！';
