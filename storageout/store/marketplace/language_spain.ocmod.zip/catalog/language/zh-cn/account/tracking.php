<?php
// 标题
$_['heading_title'] = '伙伴追踪';

// 文本
$_['text_account'] = '合作伙伴账户';
$_['text_description'] = '为了确保您可以从您发送给我们的推荐（佣金）中获得报酬，我们需要通过在链接到我们的 URL 中插入跟踪代码来跟踪推荐。 您可以使用下面的工具创建到 %s 网站的链接。';

// 入口
$_['entry_code'] = '您的跟踪代码';
$_['entry_generator'] = '跟踪链接生成器';
$_['entry_link'] = '追踪链接';

// 帮助
$_['help_generator'] = '输入您要链接的产品名称';
