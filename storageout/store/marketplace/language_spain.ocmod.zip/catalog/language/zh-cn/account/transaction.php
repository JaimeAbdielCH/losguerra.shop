<?php
// 标题
$_['heading_title'] = '金融交易清单';

// 柱子
$_['column_date_added'] = '操作日期';
$_['column_description'] = '描述/评论';
$_['column_amount'] = '金额 (%s)';

// 文本
$_['text_account'] = '客户账户';
$_['text_transaction'] = '显示金融交易';
$_['text_total'] = '您当前的余额是：';
$_['text_no_results'] = '您还没有完成任何交易或业务流程！';
