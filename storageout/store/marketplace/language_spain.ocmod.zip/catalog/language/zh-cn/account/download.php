<?php
// 标题
$_['heading_title'] = '我的下载';

// 文本
$_['text_account'] = '客户账户';
$_['text_downloads'] = '管理下载';
$_['text_no_results'] = '您还没有下订单下载附件！';

// 柱子
$_['column_order_id'] = '订单编号';
$_['column_name'] = '姓名';
$_['column_size'] = '大小';
$_['column_date_added'] = '日期';

// 错误
$_['error_not_found'] = '错误：找不到文件 %s！';
$_['error_headers_sent'] = '错误：标题已经发送！';
