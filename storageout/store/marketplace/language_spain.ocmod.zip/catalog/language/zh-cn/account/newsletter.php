<?php
// 标题
$_['heading_title'] = '订阅时事通讯';

// 文本
$_['text_account'] = '客户账户';
$_['text_newsletter'] = '时事通讯';
$_['text_success'] = '成功：您已修改订阅电子报！';

// 入口
$_['entry_newsletter'] = '订阅';
