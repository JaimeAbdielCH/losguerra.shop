<?php
// 文本
$_['text_success'] = '成功：您已更改订单！';

// 错误
$_['error_order'] = '警告：找不到订单！';
$_['error_customer'] = '警告：需要客户数据！';
$_['error_payment_address'] = '警告：需要支付地址！';
$_['error_payment_method'] = '警告：需要支付方式！';
$_['error_no_payment'] = '警告：没有可用的支付方式！';
$_['error_shipping_address'] = '警告：需要送货地址！';
$_['error_shipping_method'] = '警告：需要运输方式！';
$_['error_no_shipping'] = '警告：没有可用的送货方式！';
$_['error_stock'] = '警告：标有***的产品没有所需数量或没有库存！';
$_['error_minimum'] = '警告：%s 的最小订单价值是 %s！';
$_['error_product'] = '警告：需要产品！';
$_['error_comment'] = '警告：需要评论！';
