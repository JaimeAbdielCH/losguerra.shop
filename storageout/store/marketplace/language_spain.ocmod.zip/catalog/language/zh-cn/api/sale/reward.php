<?php
// 文本
$_['text_success'] = '成功：您的奖励积分已被应用！';
$_['text_remove'] = '成功：您的奖励积分已被移除！';

// 错误
$_['error_reward'] = '警告：请输入要使用的奖励积分数！';
$_['error_points'] = '警告：您没有 %s 奖励积分！';
$_['error_maximum'] = '警告：可以使用的最大点数是 %s！';
