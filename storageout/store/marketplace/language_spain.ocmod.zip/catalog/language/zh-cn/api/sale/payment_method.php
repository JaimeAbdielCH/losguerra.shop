<?php
// 文本
$_['text_success'] = '成功：支付方式已设置！';

// 错误
$_['error_payment_address'] = '警告：需要提供账单地址！';
$_['error_payment_method'] = '警告：需要支付方式！';
$_['error_no_payment'] = '警告：没有付款方式！';
$_['error_product'] = '警告：需要产品！';
