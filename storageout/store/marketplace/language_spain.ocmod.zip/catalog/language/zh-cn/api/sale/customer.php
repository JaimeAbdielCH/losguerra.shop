<?php
// 文本
$_['text_success'] = '您已成功更换客户';

// 错误
$_['error_customer'] = '警告：找不到客户！';
$_['error_customer_group'] = '客户组似乎无效！';
$_['error_firstname'] = '名字必须在 1 到 32 个字符之间！';
$_['error_lastname'] = '姓氏必须在 1 到 32 个字符之间！';
$_['error_email'] = '电子邮件地址似乎无效！';
$_['error_telephone'] = '电话号码。 必须介于 3 到 32 个字符之间！';
$_['error_custom_field'] = '需要 %s！';
$_['error_regex'] = '%s 不是有效输入！';
