<?php
// 文本
$_['text_success'] = '成功：API 会话开始！';

// 错误
$_['error_permission'] = '警告：您没有访问 API 的权限！';
$_['error_key'] = '警告：错误的 API 密钥！';
$_['error_ip'] = '警告：您的 IP %s 没有访问此 API 的权限！';
