<?php
// 文本
$_['text_success'] = '成功：发送方式已设置！';

// 错误
$_['error_shipping_address'] = '警告：需要送货地址！';
$_['error_shipping_method'] = '警告：需要运输方式！';
$_['error_no_shipping'] = '警告：没有可用的送货方式！';
$_['error_shipping'] = '警告：没有需要运送的产品。';
