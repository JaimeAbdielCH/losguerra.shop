<?php
// 文本
$_['text_success'] = '成功：会员佣金将应用于此订单！';
$_['text_remove'] = '成功：您的会员佣金已被删除！';

// 错误
$_['error_affiliate'] = '警告：找不到会员！';
