<?php
// 文本
$_['text_success'] = '成功：语言已更改！';

// 错误
$_['error_language'] = '警告：未找到语言！';
