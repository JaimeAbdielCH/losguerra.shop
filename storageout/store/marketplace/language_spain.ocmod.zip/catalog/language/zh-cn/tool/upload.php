<?php
// 文本
$_['text_upload'] = '您的文件上传成功！';

// 错误
$_['error_filename'] = '文件名必须在 3 到 64 个字符之间！';
$_['error_file_type'] = '无效的文件类型！';
$_['error_upload'] = '需要上传文件！';
