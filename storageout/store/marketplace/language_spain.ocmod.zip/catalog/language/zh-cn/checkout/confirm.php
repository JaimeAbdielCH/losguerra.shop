<?php
// 文本
$_['text_subscription'] = '订阅';
$_['text_subscription_trial'] = '%s 每 %d %s(s) 支付 %d 次然后 ';
$_['text_subscription_duration'] = '%s 每 %d %s(s) 支付 %d 次';
$_['text_subscription_cancel'] = '%s 每 %d %s(s) 直到终止';
$_['text_day'] = '日';
$_['text_week'] = '周';
$_['text_semi_month'] = '14 天';
$_['text_month'] = '月份';
$_['text_year'] = '年份';

// 柱子
$_['column_name'] = '产品';
$_['column_model'] = '产品编号';
$_['column_quantity'] = '数量';
$_['column_price'] = '价格/单位（总价）';
$_['column_total'] = '总计（总额）';
