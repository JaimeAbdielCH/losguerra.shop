<?php
// Heading
$_['heading_title'] = '盒子';

// Text
$_['text_cart']     = '购物车';
