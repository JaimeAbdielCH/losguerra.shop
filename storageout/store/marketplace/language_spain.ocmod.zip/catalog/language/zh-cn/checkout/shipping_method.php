<?php
// 标题
$_['heading_title'] = '送货方式';

// 文本
$_['text_success'] = '成功：您已更改发送方式！';

// 错误
$_['error_shipping_address'] = '警告：需要送货地址！';
$_['error_shipping_method'] = '警告：需要运输方式！';
$_['error_no_shipping'] = '警告：没有可用的送货方式。 请<a href="%s">联系我们</a>寻求帮助！';
