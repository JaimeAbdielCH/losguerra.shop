<?php
// Texto
$_['text_success'] = 'Éxito: ¡sesión API iniciada!';

// errores
$_['error_permission'] = 'Advertencia: ¡No tienes permiso para acceder a la API!';
$_['error_key'] = 'Advertencia: ¡Clave API incorrecta!';
$_['error_ip'] = 'Advertencia: ¡Su IP %s no tiene permiso para acceder a esta API!';
