<?php
// Texto
$_['text_success'] = 'Éxito: ¡Su cupón de descuento ha sido aplicado!';
$_['text_remove'] = 'Exitoso: ¡Su cupón de descuento ha sido eliminado!';

// errores
$_['error_coupon'] = 'Advertencia: ¡El cupón de descuento no es válido, ha caducado o ha alcanzado su límite de uso!';
