<?php
// Texto
$_['text_success'] = 'Éxito: ¡Se ha configurado el método de envío!';

// errores
$_['error_shipping_address'] = 'Advertencia: ¡Se requiere la dirección de envío!';
$_['error_shipping_method'] = 'Advertencia: ¡Se requiere método de envío!';
$_['error_no_shipping'] = 'Advertencia: ¡No hay métodos de envío disponibles!';
$_['error_shipping'] = 'Advertencia: No hay productos que requieran envío.';
