<?php
// Texto
$_['text_success'] = 'Éxito: ¡Se ha cambiado el idioma!';

// errores
$_['error_language'] = 'Advertencia: ¡No se encontró ningún idioma!';
