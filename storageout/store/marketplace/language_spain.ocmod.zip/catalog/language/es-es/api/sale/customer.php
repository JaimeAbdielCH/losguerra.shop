<?php
// Texto
$_['text_success'] = 'Ha cambiado de cliente con éxito';

// errores
$_['error_customer'] = 'Advertencia: ¡No se pudo encontrar al cliente!';
$_['error_customer_group'] = '¡El grupo de clientes no parece ser válido!';
$_['error_firstname'] = '¡El nombre debe tener entre 1 y 32 caracteres!';
$_['error_lastname'] = '¡El apellido debe tener entre 1 y 32 caracteres!';
$_['error_email'] = '¡La dirección de correo electrónico no parece ser válida!';
$_['error_telephone'] = 'El número de teléfono. debe tener entre 3 y 32 caracteres!';
$_['error_custom_field'] = '%s requerido!';
$_['error_regex'] = '%s no es una entrada válida!';
