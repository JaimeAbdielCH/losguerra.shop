<?php
// Texto
$_['text_success'] = 'Éxito: ¡Se ha establecido el método de pago!';

// errores
$_['error_payment_address'] = 'Advertencia: ¡Se requiere la dirección de facturación!';
$_['error_payment_method'] = 'Advertencia: ¡Método de pago requerido!';
$_['error_no_payment'] = 'Advertencia: ¡No hay métodos de pago!';
$_['error_product'] = 'Advertencia: ¡Los productos son obligatorios!';
