<?php
// Texto
$_['text_success'] = 'Éxito: ¡Se aplicará una comisión de afiliado a este pedido!';
$_['text_remove'] = 'Exitoso: ¡Su comisión de afiliado ha sido eliminada!';

// errores
$_['error_affiliate'] = 'Advertencia: ¡No se pudo encontrar el afiliado!';
