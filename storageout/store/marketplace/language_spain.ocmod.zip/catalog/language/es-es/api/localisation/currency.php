<?php
// Texto
$_['text_success'] = 'Éxito: ¡La moneda ha sido cambiada!';

// errores
$_['error_currency'] = 'Advertencia: ¡No se encontró moneda!';
