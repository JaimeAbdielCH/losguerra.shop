<?php
// Texto
$_['text_success'] = 'Éxito: ¡La tienda (tienda) ha sido cambiada!';

// errores
$_['error_store'] = 'Advertencia: ¡No se pudo encontrar la tienda (tienda)!';
