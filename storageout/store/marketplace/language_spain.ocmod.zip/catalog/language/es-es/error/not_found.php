<?php
// encabezado
$_['heading_title'] = '¡No se puede encontrar la página solicitada!';

// Texto
$_['text_error'] = '¡No se puede encontrar la página solicitada!';
