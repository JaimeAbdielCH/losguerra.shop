<?php
// Texto
$_['text_subject'] = '%s - actualice su orden %s';
$_['text_order_id'] = 'ID de pedido:';
$_['text_date_added'] = 'Fecha del pedido:';
$_['text_order_status'] = 'Su pedido ha sido actualizado al siguiente estado:';
$_['text_comment'] = 'Los comentarios sobre su pedido:';
$_['text_link'] = 'Para ver su pedido, haga clic en el siguiente enlace:';
$_['text_footer'] = 'Por favor, responda a este correo electrónico si tiene alguna pregunta.';
