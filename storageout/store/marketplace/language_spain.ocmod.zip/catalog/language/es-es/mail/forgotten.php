<?php
// Texto
$_['text_subject'] = '%s - Solicitud para restablecer su contraseña';
$_['text_greeting'] = 'Se ha solicitado una nueva contraseña para la cuenta de cliente %s.';
$_['text_change'] = 'Para restablecer su contraseña, haga clic en el siguiente enlace:';
$_['text_ip'] = 'La IP utilizada para esta solicitud es:';

// botones
$_['button_reset'] = 'Restablecer contraseña';
