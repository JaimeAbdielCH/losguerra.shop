<?php
// Texto
$_['text_subject'] = 'Recibió un certificado de regalo de %s';
$_['text_greeting'] = 'Felicitaciones, ha recibido un vale de regalo por valor de %s.';
$_['text_from'] = 'Este certificado de regalo le fue enviado por %s.';
$_['text_message'] = 'Con un mensaje que lee';
$_['text_redeem'] = 'Para canjear este vale de regalo, escriba el código del vale de regalo <b>%s</b>, haga clic en el enlace de abajo y compre el producto para el que desea utilizar el vale. Puede ingresar el código de cupón en la <u>Página del carrito</u> antes de pagar.';
$_['text_footer'] = 'Por favor, responda a este correo electrónico si tiene alguna pregunta.';
