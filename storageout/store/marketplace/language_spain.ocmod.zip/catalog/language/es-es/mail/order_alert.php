<?php
// Texto
$_['text_subject'] = '%s - Pedido %s';
$_['text_received'] = 'Ha recibido un nuevo pedido.';
$_['text_order_id'] = 'ID de pedido:';
$_['text_date_added'] = 'Fecha de adición:';
$_['text_order_status'] = 'Estado del pedido:';
$_['text_product'] = 'Producto(s):';
$_['text_total'] = 'Cantidad total:';
$_['text_comment'] = 'Comentarios del cliente sobre el pedido:';
