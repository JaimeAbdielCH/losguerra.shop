<?php
// Texto
$_['text_subject'] = '%s - Valoración del producto';
$_['text_waiting'] = 'Una nueva reseña de producto está esperando para ser procesada.';
$_['text_product'] = 'Producto:';
$_['text_reviewer'] = 'Revisor:';
$_['text_rating'] = 'Calificación:';
$_['text_review'] = 'Detalles de la revisión:';
