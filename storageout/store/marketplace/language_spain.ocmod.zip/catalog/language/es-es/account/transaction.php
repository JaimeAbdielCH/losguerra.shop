<?php
// encabezado
$_['heading_title'] = 'Lista de transacciones financieras';

// Columna
$_['column_date_added'] = 'Fecha de la operación';
$_['column_description'] = 'Descripción / Comentario';
$_['column_amount'] = 'Cantidad (%s)';

// Texto
$_['text_account'] = 'Cuenta de cliente';
$_['text_transaction'] = 'Mostrar transacciones financieras';
$_['text_total'] = 'Su saldo actual es:';
$_['text_no_results'] = '¡No ha completado ninguna transacción o proceso comercial!';
