<?php
// encabezado
$_['heading_title'] = 'Se ha desconectado';

// Texto
$_['text_message'] = '<p><br><b>Ha cerrado correctamente la sesión de su cuenta de cliente.</b><br>Ahora es seguro abandonar la computadora.</p><p ><b>Su carrito de compras se ha guardado</b> y los artículos que contiene se restaurarán cuando <u>inicie sesión en su cuenta de cliente</u> nuevamente.</p>';
$_['text_account'] = 'Cuenta de cliente';
$_['text_logout'] = 'El cliente está desconectado';
