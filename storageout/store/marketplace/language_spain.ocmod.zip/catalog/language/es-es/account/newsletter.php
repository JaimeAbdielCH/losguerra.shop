<?php
// encabezado
$_['heading_title'] = 'Suscribirse al boletín';

// Texto
$_['text_account'] = 'Cuenta de cliente';
$_['text_newsletter'] = 'Boletín';
$_['text_success'] = 'Éxito: ¡Ha modificado la suscripción al boletín!';

// Entrada
$_['entry_newsletter'] = 'Suscribirse';
