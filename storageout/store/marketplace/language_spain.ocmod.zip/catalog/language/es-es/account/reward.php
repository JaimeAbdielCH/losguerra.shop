<?php
// encabezado
$_['heading_title'] = 'Administrar puntos de recompensa';

// Columna
$_['column_date_added'] = 'Fecha de la operación';
$_['column_description'] = 'Descripción';
$_['column_points'] = 'Puntos';

// Texto
$_['text_account'] = 'Cuenta de cliente';
$_['text_reward'] = 'Editar puntos de recompensa';
$_['text_total'] = 'El número total de sus puntos de recompensa es:';
$_['text_no_results'] = '¡No tiene puntos de recompensa atribuidos a su cuenta de cliente!';
