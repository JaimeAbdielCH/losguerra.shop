<?php
// Texto
$_['text_upload'] = '¡Su archivo se cargó correctamente!';

// errores
$_['error_filename'] = '¡El nombre del archivo debe tener entre 3 y 64 caracteres!';
$_['error_file_type'] = '¡Tipo de archivo no válido!';
$_['error_upload'] = '¡Subir archivo requerido!';
