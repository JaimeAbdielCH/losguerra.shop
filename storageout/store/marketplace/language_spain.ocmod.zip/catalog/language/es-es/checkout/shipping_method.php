<?php
// encabezado
$_['heading_title'] = 'Método de envío';

// Texto
$_['text_success'] = 'Éxito: ¡Ha cambiado el método de envío!';

// errores
$_['error_shipping_address'] = 'Advertencia: ¡Se requiere la dirección de envío!';
$_['error_shipping_method'] = 'Advertencia: ¡Se requiere método de envío!';
$_['error_no_shipping'] = 'Advertencia: No hay métodos de envío disponibles. ¡Por favor, <a href="%s">póngase en contacto con nosotros</a> para obtener ayuda!';
