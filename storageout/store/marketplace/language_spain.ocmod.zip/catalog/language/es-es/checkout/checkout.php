<?php
// Título
$_['heading_title'] = 'Caja';

// Texto
$_['text_cart'] = 'Warenkorb';
