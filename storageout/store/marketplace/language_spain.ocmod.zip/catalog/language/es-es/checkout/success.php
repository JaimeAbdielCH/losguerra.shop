<?php
// encabezado
$_['heading_title'] = '¡Su pedido ha sido enviado!';

// Texto
$_['text_basket'] = 'Cesta';
$_['text_checkout'] = 'Pagar';
$_['text_success'] = 'Éxito';
$_['text_customer'] = '<p>¡Su pedido se ha procesado correctamente!</p><p> Puede ver su historial de pedidos yendo a <a href="%s">Mi cuenta de cliente</ a> y haga clic en <a href="%s">Historial</a>.</p><p>Si su compra incluye una descarga, puede verla en <a href= "%s">Ver su descargas de la cuenta</a>.</p><p>Si tiene alguna pregunta, comuníquese con <a href="%s">nuestro personal</a>.</p ><p>Gracias por realizar su pedido en ¡¡nosotros!!</p>';
$_['text_guest'] = '<p>¡Su pedido se ha procesado correctamente!</p><p>Si tiene alguna pregunta, comuníquese con nuestro <a href="%s">personal</a>. </ p><p>¡Gracias por comprar con nosotros en línea!</p>';
