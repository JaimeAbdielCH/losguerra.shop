<?php
// Texto
$_['text_subscription'] = 'Suscripción';
$_['text_subscription_trial'] = '%s cada %d %s(s) para %d pago(s) luego ';
$_['text_subscription_duration'] = '%s cada %d %s(s) para %d pago(s)';
$_['text_subscription_cancel'] = '%s cada %d %s(s) hasta que termine';
$_['text_day'] = 'Día';
$_['text_week'] = 'Semana';
$_['text_semi_month'] = '14 días';
$_['text_month'] = 'Mes';
$_['text_year'] = 'Año';

// Columna
$_['column_name'] = 'Producto';
$_['column_model'] = 'ID del producto';
$_['column_quantity'] = 'Cantidad';
$_['column_price'] = 'Precio / Unidad (bruto)';
$_['column_total'] = 'Total (bruto)';
