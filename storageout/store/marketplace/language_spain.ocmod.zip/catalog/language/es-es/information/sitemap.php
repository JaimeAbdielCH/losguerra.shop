<?php
// encabezado
$_['heading_title'] = 'Mapa del sitio';

// Texto
$_['text_special'] = 'Ofertas especiales';
$_['text_account'] = 'Mi cuenta de cliente';
$_['text_edit'] = 'Editar cuenta de cliente';
$_['text_password'] = 'Cambiar contraseña';
$_['text_address'] = 'Administrar libreta de direcciones';
$_['text_history'] = 'Ver pedidos';
$_['text_download'] = 'Administrar descargas';
$_['text_cart'] = 'Carrito';
$_['text_checkout'] = 'Pagar';
$_['text_search'] = 'Buscar';
$_['text_information'] = 'Información';
$_['text_contact'] = 'Información de contacto';
