<?php
// encabezado
$_['heading_title'] = 'GDPR-Exitoso';

// Texto
$_['text_account'] = 'Cuenta de cliente';
$_['text_export'] = 'Hemos recibido una solicitud para exportar la información de su cuenta.';
$_['text_remove'] = 'Las solicitudes de eliminación de cuenta de GDPR se procesarán después de <strong>%s días</strong> para permitir que se procesen las devoluciones de cargo, los reembolsos o las investigaciones de fraude.';
