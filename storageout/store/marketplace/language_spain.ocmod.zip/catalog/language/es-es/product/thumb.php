<?php
// Texto
$_['text_price'] = 'Precio / Unidad:';
$_['text_tax'] = 'Precio (neto):';
