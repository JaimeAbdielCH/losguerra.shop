<?php
// Texto
$_['text_currency'] = 'Moneda';
