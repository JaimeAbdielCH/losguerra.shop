<?php
// Texto
$_['text_wishlist'] = 'Lista de deseos (%s)';
$_['text_shopping_cart'] = 'Carrito';
$_['text_account'] = 'Cuenta de cliente';
$_['text_register'] = 'Registrar nuevo';
$_['text_login'] = 'Iniciar sesión';
$_['text_order'] = 'Mis pedidos';
$_['text_transaction'] = 'Mis transacciones financieras';
$_['text_download'] = 'Mis descargas';
$_['text_logout'] = 'Cerrar sesión';
$_['text_checkout'] = 'Pagar';
