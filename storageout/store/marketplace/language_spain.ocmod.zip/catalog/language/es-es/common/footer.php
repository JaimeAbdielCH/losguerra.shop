<?php
// Texto
$_['text_information'] = 'Información';
$_['text_service'] = 'Servicio al Cliente';
$_['text_extra'] = 'Extras';
$_['text_contact'] = 'Información de contacto';
$_['text_return'] = 'Devoluciones';
$_['text_sitemap'] = 'Mapa del sitio';
$_['text_gdpr'] = 'RGPD';
$_['text_manufacturer'] = 'Fabricantes y marcas';
$_['text_voucher'] = 'Vales regalo';
$_['text_afiliado'] = 'Programa de Afiliados';
$_['text_special'] = 'Ofertas especiales';
$_['text_account'] = 'Mi Cuenta';
$_['text_order'] = 'Ver pedidos';
$_['text_wishlist'] = 'Editar lista de deseos';
$_['text_newsletter'] = 'Administrar boletín';
$_['text_powered'] = 'Desarrollado por <a href="https://www.opencart.com">OpenCart</a><br/> %s &copy; %s';
