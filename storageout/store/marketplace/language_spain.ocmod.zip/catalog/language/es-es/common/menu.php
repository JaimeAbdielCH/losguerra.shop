<?php
// Texto
$_['text_category'] = 'Categorías';
$_['text_all'] = 'Mostrar todo';
