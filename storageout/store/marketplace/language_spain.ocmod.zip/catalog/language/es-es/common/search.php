<?php
// Texto
$_['text_search'] = 'Buscar';
