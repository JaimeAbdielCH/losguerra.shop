<?php
// Texto
$_['text_language'] = 'Idioma';
