<?php
// Texto
$_['text_success'] = '¡Gracias por hacernos saber su elección!';
$_['text_cookie'] = 'Este sitio web utiliza cookies. Para más información <a href="%s" class="alert-link modal-link">haga clic aquí</a>.';

// botones
$_['button_agree'] = '¡De acuerdo!';
$_['button_disagree'] = '¡No, gracias!';
