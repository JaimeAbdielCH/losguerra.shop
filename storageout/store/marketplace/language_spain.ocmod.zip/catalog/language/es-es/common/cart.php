<?php
// Texto
$_['text_items'] = '%s elemento(s) - %s';
$_['text_subscription'] = 'Suscripción';
$_['text_subscription_trial'] = '%s cada %d %s(s) para %d pago(s) luego ';
$_['text_subscription_duration'] = '%s cada %d %s(s) para %d pago(s)';
$_['text_subscription_cancel'] = '%s cada %d %s(s) hasta que finalice';
$_['text_day'] = 'Día(s)';
$_['text_week'] = 'Semana(s)';
$_['text_semi_month'] = '14 días';
$_['text_month'] = 'mes(es)';
$_['text_year'] = 'Año(s)';
$_['text_no_results'] = '¡Tu carrito de compras está vacío!';
$_['text_cart'] = 'Mostrar carrito';
$_['text_checkout'] = 'Pagar';
