<?php
// encabezado
$_['heading_title'] = 'Mantenimiento';

// Texto
$_['text_maintenance'] = 'Modo de mantenimiento';
$_['text_message'] = '<h1 style="text-align:center;">Actualmente estamos realizando un mantenimiento programado. <br/>Volveremos lo antes posible. Vuelve pronto.</h1>';
